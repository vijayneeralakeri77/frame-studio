-- Run this in Supabase SQL Editor.
-- Keep the service-role key server-side only. Never expose it as NEXT_PUBLIC_*.

create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  customer_name text not null check (char_length(customer_name) between 2 and 100),
  customer_email text not null,
  contact text,
  service text not null,
  budget text,
  deadline date,
  brief text not null,
  status text not null default 'new'
    check (status in ('new','quoted','awaiting_upload','editing','review','completed','cancelled')),
  quoted_amount numeric(10,2),
  internal_notes text,
  delivery_path text
);

alter table public.orders enable row level security;

-- No public policies are added intentionally. Browser clients cannot read or write orders.
-- Server API uses the service-role key. Before public launch, add rate limiting / CAPTCHA,
-- email verification, retention rules, and authenticated admin access.
