"use client";

import { FormEvent, useState } from "react";

export default function OrderForm() {
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setStatus("");
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      const response = await fetch("/api/orders", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Could not submit your request.");
      setStatus(`Request received. Your reference is ${result.orderId}. Keep it for your records.`);
      form.reset();
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Something went wrong. Please try again.");
    } finally { setBusy(false); }
  }

  return <form className="form" onSubmit={submit}>
    <div className="formgrid">
      <div className="field"><label htmlFor="name">Your name *</label><input id="name" name="name" required minLength={2} maxLength={100} placeholder="Full name"/></div>
      <div className="field"><label htmlFor="email">Email address *</label><input id="email" name="email" required type="email" maxLength={254} placeholder="you@example.com"/></div>
    </div>
    <div className="formgrid">
      <div className="field"><label htmlFor="service">What do you need? *</label><select id="service" name="service" required defaultValue=""><option value="" disabled>Select a service</option><option>Video editing</option><option>Wedding / event film</option><option>Reels / short-form content</option><option>YouTube video</option><option>Brand / product film</option><option>Other</option></select></div>
      <div className="field"><label htmlFor="budget">Approximate budget</label><select id="budget" name="budget" defaultValue=""><option value="">Choose a range</option><option>Under ₹2,000</option><option>₹2,000–₹5,000</option><option>₹5,000–₹15,000</option><option>₹15,000+</option><option>Need a quote</option></select></div>
    </div>
    <div className="formgrid">
      <div className="field"><label htmlFor="deadline">Preferred deadline</label><input id="deadline" name="deadline" type="date"/></div>
      <div className="field"><label htmlFor="contact">Phone / WhatsApp (optional)</label><input id="contact" name="contact" maxLength={30} placeholder="+91"/></div>
    </div>
    <div className="field"><label htmlFor="brief">Tell us about your project *</label><textarea id="brief" name="brief" required minLength={10} maxLength={4000} placeholder="Video style, length, platform, references, and any special instructions..."/></div>
    <button className="pill" type="submit" disabled={busy}>{busy ? "Sending request…" : "Send project request ↗"}</button>
    {status && <p className="form-message" role="status">{status}</p>}
    <p className="note">Submitting this form does not confirm a booking or payment.</p>
  </form>;
}
