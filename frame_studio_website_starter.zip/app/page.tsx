import OrderForm from "@/components/OrderForm";

const work = [
  { category: "Wedding film", title: "A day to remember", image: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=85" },
  { category: "Brand story", title: "Made with intention", image: "https://images.unsplash.com/photo-1492619375914-88005aa9e8fb?auto=format&fit=crop&w=900&q=85" },
  { category: "Travel film", title: "Somewhere beyond", image: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=900&q=85" },
];

export default function Home() {
  return <main>
    <header className="wrap nav">
      <a className="logo" href="#" aria-label="FRAME home">FRAME<span>.</span></a>
      <nav className="navlinks"><a href="#work">Selected work</a><a href="#services">Services</a><a className="pill" href="#order">Start a project ↗</a></nav>
    </header>
    <section className="wrap hero">
      <div>
        <div className="eyebrow">Independent video studio · India</div>
        <h1>Stories worth<br/> <em>feeling.</em></h1>
        <p className="lead">Cinematic films, thoughtful edits, and visuals that stay with you. Tell us what you're imagining — we'll help bring it to life.</p>
        <div className="actions"><a className="pill" href="#order">Start your project ↗</a><a className="secondary" href="#work">Explore the work ↓</a></div>
      </div>
      <div className="hero-art" role="img" aria-label="Cinematic film camera in a dark movie theatre">
        <div className="art-label"><div><small>THE ART OF THE FRAME</small><br/><strong>Every second matters.</strong></div><small>01 / SHOWREEL</small></div>
      </div>
    </section>
    <section className="wrap section" id="work">
      <div className="section-head"><div><div className="eyebrow">Selected projects</div><h2 style={{marginTop:10}}>A few frames from our world.</h2></div><p className="muted">Replace these demo images with your own work<br/>and link each card to a video showreel.</p></div>
      <div className="grid3">{work.map((item) => <article className="work" key={item.title}><img src={item.image} alt={item.title} /><div className="work-caption"><small>{item.category}</small><h3>{item.title}</h3></div></article>)}</div>
    </section>
    <section className="wrap section" id="services">
      <div className="section-head"><div><div className="eyebrow">What we do</div><h2 style={{marginTop:10}}>From raw clips to final cut.</h2></div></div>
      <div className="services">
        <article className="service"><span className="num">01 / FILM</span><h3>Videography</h3><p>Events, weddings, portraits, travel films, and brand stories captured with intention.</p></article>
        <article className="service"><span className="num">02 / EDIT</span><h3>Video editing</h3><p>Reels, YouTube videos, highlight films, pacing, sound design, and cinematic color grading.</p></article>
        <article className="service"><span className="num">03 / CREATE</span><h3>Content packages</h3><p>Consistent short-form content for creators, local businesses, and growing brands.</p></article>
      </div>
    </section>
    <section className="wrap section" id="order">
      <div className="order-layout">
        <div><div className="eyebrow">Let's make something</div><h2 style={{marginTop:12}}>Your idea.<br/><span style={{color:"var(--accent)"}}>Our next project.</span></h2><p className="muted">Share a few details and we'll get back to you with next steps, pricing, and a delivery timeline.</p><p className="note">Have large footage files? Submit this brief first. The studio will provide a private upload link after reviewing the request. This avoids exposing raw footage in a public form.</p></div>
        <OrderForm />
      </div>
    </section>
    <footer className="wrap footer"><span>© {new Date().getFullYear()} FRAME STUDIO. Replace with your brand.</span><span>Made for stories that matter.</span></footer>
  </main>;
}
