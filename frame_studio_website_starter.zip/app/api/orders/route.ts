import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabaseAdmin";

export const runtime = "nodejs";

function clean(value: unknown, max = 4000) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = clean(body.name, 100);
    const email = clean(body.email, 254).toLowerCase();
    const service = clean(body.service, 100);
    const brief = clean(body.brief, 4000);
    const budget = clean(body.budget, 50);
    const deadline = clean(body.deadline, 20) || null;
    const contact = clean(body.contact, 30) || null;

    if (name.length < 2 || !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email) || !service || brief.length < 10) {
      return NextResponse.json({ error: "Please check the required fields and try again." }, { status: 400 });
    }

    const supabase = getSupabaseAdmin();
    const { data, error } = await supabase.from("orders").insert({
      customer_name: name, customer_email: email, contact, service, budget, deadline, brief,
      status: "new"
    }).select("id").single();

    if (error) {
      console.error("Order insert failed:", error.message);
      return NextResponse.json({ error: "We couldn't save your request. Please try again later." }, { status: 500 });
    }
    return NextResponse.json({ ok: true, orderId: data.id }, { status: 201 });
  } catch (error) {
    console.error("Order API error:", error instanceof Error ? error.message : "unknown");
    return NextResponse.json({ error: "Server setup is incomplete or the request could not be processed." }, { status: 500 });
  }
}
