# FRAME Studio — starter website

A cinematic-dark Next.js starter for a videography / video-editing business.

## Included
- Responsive portfolio landing page and service cards
- Project request form with basic input validation
- Supabase-backed order creation API
- Starter order schema with project status fields
- Setup notes for secure upload and private delivery

## Requirements
- Node.js 20+
- A Supabase project
- Optional: GitHub and Vercel account for deployment

## Run locally
1. Extract this ZIP and open the folder in a terminal.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. In Supabase, open SQL Editor and run `supabase/schema.sql`.
5. Add your project URL and anon key to `.env.local`.
6. Add the Supabase service-role key as `SUPABASE_SERVICE_ROLE_KEY`. This key must stay server-side and must never be committed or exposed in browser code.
7. Run `npm run dev` and open `http://localhost:3000`.

The order form will only save requests after the Supabase environment variables and schema are configured.

## Customize the brand
- Change `FRAME` and the title/description in `app/page.tsx` and `app/layout.tsx`.
- Replace demo portfolio images with your own licensed images or video thumbnails.
- Add real showreel URLs to portfolio cards.
- Change the service options and budget bands to match your pricing.

## Important: uploads and client delivery
This starter deliberately does **not** expose a public upload endpoint. Large raw clips should not be uploaded through the order form or stored in a public bucket.

Before accepting real customers, implement:
1. Customer authentication or a verified, one-time upload invitation linked to an order.
2. Server-created short-lived signed upload URLs (or a provider's multipart/resumable upload flow for large files).
3. Private storage buckets; enforce file-size and content-type limits; use random object keys.
4. Upload authorization that checks the invitation/order and prevents users from accessing other customers' files.
5. Admin authentication and role checks before showing customer orders or internal notes.
6. Private delivery links with expiry, access logging, and a retention/deletion policy.
7. Rate limiting, bot protection, email notifications, backups, and privacy/terms pages.

For very large files, Cloudflare R2 with multipart uploads or a managed upload service can be a good fit. Supabase Storage can be simpler to start with. Check current plan limits and pricing before choosing.

## Production checklist
- Do not commit `.env.local`.
- Never put the Supabase service-role key in a `NEXT_PUBLIC_` variable.
- Add rate limiting / CAPTCHA to the public order endpoint.
- Add server-side schema validation and abuse controls.
- Add a protected admin dashboard; this starter does not include one yet.
- Test on mobile and desktop.
- Add your own privacy policy, terms, contact details, and portfolio rights.
